// routes/admin.js

const express = require('express');
const router = express.Router();
const verifyToken = require('../middleware/authMiddleware');
const isAdmin = require('../middleware/isAdmin');
const db = require('../config/db'); // ⬅️ DB 연결 객체가 있다고 가정

// ✅ 관리자 접근 확인용
router.get('/dashboard', verifyToken, isAdmin, (req, res) => {
  res.json({ message: '관리자 대시보드 접근 성공' });
});

// ✅ 전체 회원 목록 조회
router.get('/users', verifyToken, isAdmin, async (req, res) => {
  try {
    const [users] = await db.query(
      'SELECT id, name, username, is_admin, created_at FROM users'
    );
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: '회원 조회 실패', error: err.message });
  }
});

// ✅ 회원 권한 변경 (관리자 여부)
router.put('/users/:id/role', verifyToken, isAdmin, async (req, res) => {
  const { is_admin } = req.body;
  const userId = req.params.id;

  try {
    await db.query('UPDATE users SET is_admin = ? WHERE id = ?', [is_admin, userId]);
    res.json({ message: '회원 권한 변경 완료' });
  } catch (err) {
    res.status(500).json({ message: '권한 변경 실패', error: err.message });
  }
});

// ✅ 회원 삭제
router.delete('/users/:id', verifyToken, isAdmin, async (req, res) => {
  const userId = req.params.id;

  try {
    await db.query('DELETE FROM users WHERE id = ?', [userId]);
    res.json({ message: '회원 삭제 완료' });
  } catch (err) {
    res.status(500).json({ message: '회원 삭제 실패', error: err.message });
  }
});

// ✅ 게시글 전체 조회
router.get('/posts', verifyToken, isAdmin, async (req, res) => {
  try {
    const [posts] = await db.query('SELECT * FROM posts ORDER BY created_at DESC');
    res.json(posts);
  } catch (err) {
    res.status(500).json({ message: '게시글 조회 실패', error: err.message });
  }
});

// ✅ 게시글 삭제
router.delete('/posts/:id', verifyToken, isAdmin, async (req, res) => {
  const postId = req.params.id;

  try {
    await db.query('DELETE FROM posts WHERE id = ?', [postId]);
    res.json({ message: '게시글 삭제 완료' });
  } catch (err) {
    res.status(500).json({ message: '게시글 삭제 실패', error: err.message });
  }
});


module.exports = router;
