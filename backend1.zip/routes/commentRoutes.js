const express = require('express');
const router = express.Router();
const {
  addComment,
  getCommentsByPostId,
  updateComment,
  deleteComment
} = require('../controllers/commentController');

const verifyToken = require('../middleware/authMiddleware');

router.get('/:postId', getCommentsByPostId);                    // 게시글의 댓글 목록
router.post('/:postId', verifyToken, addComment);              // 댓글 작성
router.put('/:commentId', verifyToken, updateComment);         // 댓글 수정
router.delete('/:commentId', verifyToken, deleteComment);      // 댓글 삭제

module.exports = router;
