const pool = require('../config/db');

// 📥 게시글 생성
exports.createPost = async (req, res) => {
  const { category, title, content } = req.body;
  const author = req.user.username;
  const authorId = req.user.id;

  try {
    const [result] = await pool.query(
      `INSERT INTO posts (category, title, content, author, author_id) VALUES (?, ?, ?, ?, ?)`,
      [category, title, content, author, authorId]
    );

    res.status(201).json({ id: result.insertId, message: '게시글 등록 완료' });
  } catch (err) {
    res.status(500).json({ message: '게시글 생성 실패', error: err.message });
  }
};

// 📚 전체 게시글 조회
exports.getAllPosts = async (req, res) => {
  try {
    const [rows] = await pool.query(`
  SELECT 
    p.*, 
    COUNT(l.id) AS likes
  FROM posts p
  LEFT JOIN likes l ON p.id = l.post_id
  GROUP BY p.id
  ORDER BY p.created_at DESC
`);

    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ message: '게시글 목록 불러오기 실패' });
  }
};

// 🔍 단일 게시글 조회
exports.getPostById = async (req, res) => {
  const { id } = req.params;
  try {
    const [rows] = await pool.query(`
  SELECT 
    p.*, 
    COUNT(l.id) AS likes
  FROM posts p
  LEFT JOIN likes l ON p.id = l.post_id
  WHERE p.id = ?
  GROUP BY p.id
`, [id]);

    if (rows.length === 0) return res.status(404).json({ message: '게시글 없음' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ message: '게시글 조회 실패' });
  }
};

// ✏️ 게시글 수정
exports.updatePost = async (req, res) => {
  const { id } = req.params;
  const { category, title, content } = req.body;
  const authorId = req.user.id;

  try {
    const [rows] = await pool.query(`SELECT * FROM posts WHERE id = ?`, [id]);
    if (!rows.length) return res.status(404).json({ message: '게시글 없음' });
    if (rows[0].author_id !== authorId) return res.status(403).json({ message: '작성자만 수정 가능' });

    await pool.query(
      `UPDATE posts SET category = ?, title = ?, content = ?, updated_at = NOW() WHERE id = ?`,
      [category, title, content, id]
    );

    res.json({ message: '게시글 수정 완료' });
  } catch (err) {
    res.status(500).json({ message: '게시글 수정 실패' });
  }
};

// 🗑 게시글 삭제
exports.deletePost = async (req, res) => {
  const { id } = req.params;
  const authorId = req.user.id;

  try {
    const [rows] = await pool.query(`SELECT * FROM posts WHERE id = ?`, [id]);
    if (!rows.length) return res.status(404).json({ message: '게시글 없음' });
    if (rows[0].author_id !== authorId) return res.status(403).json({ message: '작성자만 삭제 가능' });

    await pool.query(`DELETE FROM posts WHERE id = ?`, [id]);
    res.json({ message: '삭제 완료' });
  } catch (err) {
    res.status(500).json({ message: '게시글 삭제 실패' });
  }
};

// ❤️ 좋아요 토글
exports.likePost = async (req, res) => {
  const postId = req.params.id;
  const userId = req.user.id;

  try {
    // 좋아요가 이미 되어 있는지 확인
    const [existing] = await pool.query(
      `SELECT * FROM likes WHERE user_id = ? AND post_id = ?`,
      [userId, postId]
    );

    if (existing.length > 0) {
      // 좋아요 취소
      await pool.query(
        `DELETE FROM likes WHERE user_id = ? AND post_id = ?`,
        [userId, postId]
      );
    } else {
      // 좋아요 등록
      await pool.query(
        `INSERT INTO likes (user_id, post_id) VALUES (?, ?)`,
        [userId, postId]
      );
    }

    // 변경된 좋아요 수 조회
    const [likeCountResult] = await pool.query(
      `SELECT COUNT(*) AS likeCount FROM likes WHERE post_id = ?`,
      [postId]
    );

    const likeCount = likeCountResult[0].likeCount;

    res.json({
      liked: existing.length === 0, // true면 좋아요 추가, false면 취소
      likes: likeCount,
      message: existing.length === 0 ? '좋아요 등록됨' : '좋아요 취소됨'
    });
  } catch (err) {
    res.status(500).json({ message: '좋아요 처리 실패', error: err.message });
  }
};

