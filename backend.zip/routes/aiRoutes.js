// ✅ 최신 SDK 사용 방식
const express = require('express');
const router = express.Router();
require('dotenv').config();

const OpenAI = require('openai'); // ✅ 변경된 import

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

router.post('/ask', async (req, res) => {
  const { question } = req.body;

  if (!question) {
    return res.status(400).json({ error: '질문이 없습니다.' });
  }

  try {
    const chatCompletion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: question }],
    });

    res.json({ answer: chatCompletion.choices[0].message.content });
  } catch (error) {
    console.error('AI 오류:', error);
    res.status(500).json({ error: 'AI 응답 실패' });
  }
});

module.exports = router;
