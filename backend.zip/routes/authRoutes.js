const express = require('express');
const router = express.Router();
const verifyToken = require('../middleware/authMiddleware');
const {
  register, login, profile,
  changePassword, deleteAccount
} = require('../controllers/authController');

router.put('/change-password', verifyToken, changePassword);
router.delete('/delete', verifyToken, deleteAccount);


router.post('/register', register);
router.post('/login', login);
router.get('/profile', verifyToken, profile);

module.exports = router;
