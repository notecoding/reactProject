const pool = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.register = async (req, res) => {
  const { name, username, password } = req.body;
  try {
    const [existing] = await pool.query('SELECT * FROM users WHERE username = ?', [username]);
    if (existing.length > 0) return res.status(400).json({ message: '이미 존재하는 아이디입니다.' });

    const hashed = await bcrypt.hash(password, 10);
    await pool.query('INSERT INTO users (name, username, password) VALUES (?, ?, ?)', [name, username, hashed]);
    res.status(201).json({ message: '회원가입 성공' });
  } catch (err) {
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
};

exports.login = async (req, res) => {
  const { username, password } = req.body;

  try {
    // 1. 사용자 조회
    const [rows] = await pool.query('SELECT * FROM users WHERE username = ?', [username]);

    if (rows.length === 0) {
      return res.status(401).json({ message: '존재하지 않는 사용자입니다.' });
    }

    const user = rows[0];

    // 2. 비밀번호 확인
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: '비밀번호가 일치하지 않습니다.' });
    }

    // 3. 사용자 정보 구성 (프론트 전달용)
    const userData = {
      id: user.id,
      name: user.name,
      username: user.username,
      isAdmin: user.is_admin === 1 || user.is_admin === true // ✅ 핵심: 관리자 여부 포함
    };

    // 4. JWT 생성
    const token = jwt.sign(userData, process.env.JWT_SECRET, { expiresIn: '1d' });

    // 5. 응답 반환
    res.json({ token, user: userData });
  } catch (err) {
    console.error('로그인 실패:', err);
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
};

exports.profile = async (req, res) => {
  const userId = req.user.id;
  try {
    const [rows] = await pool.query('SELECT id, name, username FROM users WHERE id = ?', [userId]);
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
};

exports.changePassword = async (req, res) => {
  const { password } = req.body;
  const userId = req.user.id;

  if (!password) return res.status(400).json({ message: '새 비밀번호를 입력해주세요.' });

  try {
    const hashed = await bcrypt.hash(password, 10);
    await pool.query('UPDATE users SET password = ? WHERE id = ?', [hashed, userId]);
    res.json({ message: '비밀번호가 변경되었습니다.' });
  } catch (err) {
    res.status(500).json({ message: '비밀번호 변경 실패', error: err.message });
  }
};

exports.deleteAccount = async (req, res) => {
  const userId = req.user.id;

  try {
    await pool.query('DELETE FROM users WHERE id = ?', [userId]);
    res.json({ message: '계정이 삭제되었습니다.' });
  } catch (err) {
    res.status(500).json({ message: '회원 탈퇴 실패', error: err.message });
  }
};

