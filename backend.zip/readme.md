📘 README.md – MyBoard 프로젝트 실행 설명서
md
복사
편집
# 📝 MyBoard - 게시판 웹 애플리케이션

MyBoard는 React, Express, MySQL, JWT를 기반으로 만든 **풀스택 게시판 웹사이트**입니다.  
로그인/회원가입, 글쓰기, 댓글, 좋아요, 카테고리 관리 기능을 제공합니다.

---

## 📁 프로젝트 구조

myboard-project/
├── client/ # React 프론트엔드
├── server/ # Express 백엔드
└── myboard.sql # MySQL 테이블 생성 스크립트

yaml
복사
편집

---

## 🚀 설치 및 실행 방법

### ✅ 1. MySQL 데이터베이스 준비

1. MySQL에 접속 후 데이터베이스 생성:

```sql
CREATE DATABASE myboard;
USE myboard;
myboard.sql 스크립트 실행:

bash
복사
편집
source myboard.sql
또는 MySQL Workbench를 이용해 실행하세요.

✅ 2. 백엔드 실행
bash
복사
편집
cd server
npm install
.env 파일 생성:

env
복사
편집
PORT=5000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=yourpassword
DB_NAME=myboard
JWT_SECRET=myjwtsecret
서버 실행:

bash
복사
편집
npm start
서버는 http://localhost:5000 에서 실행됩니다.

✅ 3. 프론트엔드 실행
bash
복사
편집
cd client
npm install
npm start
프론트는 http://localhost:3000 에서 실행됩니다.

✨ 주요 기능
기능	설명
🔐 회원가입 / 로그인	JWT 인증, 사용자 정보 저장
📝 글쓰기 / 수정 / 삭제	카테고리 선택, 본인만 수정 가능
💬 댓글 작성 / 수정 / 삭제	본인만 가능
❤️ 좋아요 기능	로그인한 사용자만 가능
📂 카테고리 관리	관리자 전용 (추가/수정/삭제/순서 변경)
🔍 게시글 검색	제목 기준 검색 모달 제공
🧑 내 프로필	내가 쓴 글 보기, 비밀번호 변경, 회원 탈퇴 가능

🧪 API 테스트
Postman 또는 Thunder Client로 테스트할 수 있는 주요 엔드포인트 예시:

POST /api/auth/login

GET /api/posts

POST /api/comments/:postId

POST /api/categories/reorder

📦 사용 기술 스택
분야	기술
프론트엔드	React, React Router, Axios, Context API
백엔드	Express.js, MySQL, bcrypt, jsonwebtoken
DB	MySQL 8+
기타	JWT, CORS, dotenv

🔧 개선 아이디어 (선택 사항)
댓글/게시글 페이지네이션

이미지 업로드

북마크/조회수 기능

관리자 대시보드