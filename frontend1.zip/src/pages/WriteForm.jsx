// 📁 src/pages/WriteForm.jsx

import React, { useContext, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { PostContext } from '../context/PostContext';
import { CategoryContext } from '../context/CategoryContext';
import { AuthContext } from '../context/AuthContext';
import '../styles/WriteForm.css';

const WriteForm = () => {
  const { user } = useContext(AuthContext);
  const { categories } = useContext(CategoryContext);
  const {
    createPost,
    updatePost,
    getPost,
  } = useContext(PostContext);

  const { id } = useParams(); // 수정용 postId
  const navigate = useNavigate();

  const [category, setCategory] = useState('');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isEditing, setIsEditing] = useState(false);

  // 수정 모드인 경우 기존 게시글 데이터 불러오기
  useEffect(() => {
    const fetchPost = async () => {
      if (id) {
        const data = await getPost(id);
        setCategory(data.category);
        setTitle(data.title);
        setContent(data.content);
        setIsEditing(true);
      }
    };
    fetchPost();
  }, [id]);

  // 로그인 여부 확인
  useEffect(() => {
    if (!user) {
      alert('로그인이 필요합니다.');
      navigate('/');
    }
  }, [user, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!title.trim() || !content.trim() || !category) {
      alert('모든 항목을 입력해주세요.');
      return;
    }

    const postData = { category, title, content };

    try {
      if (isEditing) {
        await updatePost(id, postData);
        alert('수정 완료!');
        navigate(`/post/${id}`);
      } else {
        const res = await createPost(postData);
        alert('작성 완료!');
        navigate(`/post/${res.id}`);
      }
    } catch (err) {
      alert('오류 발생');
    }
  };

  return (
    <div className="write-form-container">
      <div className="write-form">
        {/* 상단 바 */}
        <div className="top-bar">
          <button onClick={() => navigate(-1)}>← 뒤로</button>
          <div className="center">{isEditing ? '글 수정하기' : '새 글 작성'}</div>
          <button onClick={handleSubmit} disabled={!title || !content}>
            저장
          </button>
        </div>

        {/* 입력 폼 */}
        <div className="form">
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            <option value="">카테고리 선택</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.name}>
                {cat.name}
              </option>
            ))}
          </select>

          <input
            type="text"
            placeholder="제목을 입력하세요"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />

          <textarea
            placeholder="내용을 작성하세요"
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />

          <div className="author">작성자: {user?.name}</div>

          <div className="notice">
            ※ 욕설, 비방, 광고성 게시물은 삭제될 수 있습니다.<br />
            ※ 게시글 수정은 본인만 가능합니다.
          </div>
        </div>

        {/* 푸터 아이콘 바 (기본 형태, 향후 확장 가능) */}
        <div className="footer-icons">
          <i>🖋</i>
          <i>🧾</i>
          <i>📎</i>
          <i>📷</i>
        </div>
      </div>
    </div>
  );
};

export default WriteForm;
