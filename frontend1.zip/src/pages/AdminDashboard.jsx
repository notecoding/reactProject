import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../api/axios';
import '../styles/AdminDashboard.css';
import { Link } from 'react-router-dom'; // 상단에 추가

const AdminDashboard = () => {
  const [authorized, setAuthorized] = useState(null); // 관리자 여부 확인용
  const [users, setUsers] = useState([]);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  
  

  const fetchData = async () => {
    try {
      await axios.get('/admin/dashboard'); // 관리자 인증 체크
      setAuthorized(true);

      const [userRes, postRes] = await Promise.all([
        axios.get('/admin/users'),
        axios.get('/admin/posts'),
      ]);
      setUsers(userRes.data);
      setPosts(postRes.data);
    } catch (err) {
      setAuthorized(false);
      alert('관리자 권한이 필요합니다.');
      navigate('/login'); // 또는 navigate('/board/all')
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const toggleAdmin = async (id, current) => {
    try {
      await axios.put(`/admin/users/${id}/role`, { is_admin: current ? 0 : 1 });
      setUsers(users.map(u => u.id === id ? { ...u, is_admin: current ? 0 : 1 } : u));
    } catch (err) {
      alert('권한 변경 실패: ' + err.response?.data?.message || err.message);
    }
  };

  const deleteUser = async (id) => {
    if (!window.confirm('정말 삭제하시겠습니까?')) return;
    try {
      await axios.delete(`/admin/users/${id}`);
      setUsers(users.filter(u => u.id !== id));
    } catch (err) {
      alert('회원 삭제 실패: ' + err.response?.data?.message || err.message);
    }
  };

  const deletePost = async (id) => {
    if (!window.confirm('게시글을 삭제하시겠습니까?')) return;
    try {
      await axios.delete(`/admin/posts/${id}`);
      setPosts(posts.filter(p => p.id !== id));
    } catch (err) {
      alert('게시글 삭제 실패: ' + err.response?.data?.message || err.message);
    }
  };

  
  if (loading) return <div>로딩 중...</div>;
  if (authorized === false) return null; // 접근 차단된 경우 아무것도 렌더링하지 않음

  return (
    <div className="admin-dashboard">
      <h1>🔐 관리자 대시보드</h1>

      <section>
        <h2>👥 회원 관리</h2>
        <table className="admin-table">
          <thead>
            <tr>
              <th>ID</th><th>이름</th><th>아이디</th><th>관리자</th><th>가입일</th><th>관리</th>
            </tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u.id}>
                <td>{u.id}</td>
                <td>{u.name}</td>
                <td>{u.username}</td>
                <td>{u.is_admin ? '✅' : '❌'}</td>
                <td>{new Date(u.created_at).toLocaleDateString()}</td>
                <td>
                  <button onClick={() => toggleAdmin(u.id, u.is_admin)}>권한 변경</button>
                  <button onClick={() => deleteUser(u.id)}>삭제</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section>
        <h2>📝 게시글 관리</h2>
        <table className="admin-table">
          <thead>
            <tr>
              <th>ID</th><th>제목</th><th>작성일</th><th>관리</th>
            </tr>
          </thead>
          <tbody>
            {posts.map(p => (
              <tr key={p.id}>
                <td>{p.id}</td>
                <td>
                    <Link to={`/post/${p.id}`} target="_blank" rel="noopener noreferrer">
                    {p.title}
                  </Link>
                </td>
                <td>{new Date(p.created_at).toLocaleDateString()}</td>
                <td>
                  <button onClick={() => deletePost(p.id)}>삭제</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      </div>
  );
};

export default AdminDashboard;
