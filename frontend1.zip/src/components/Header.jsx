// 📁 src/components/Header.jsx

import React, { useContext, useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { CategoryContext } from '../context/CategoryContext';
import '../styles/Header.css';

const Header = ({
  toggleLoginModal,
  toggleRegisterModal,
  toggleSearchModal,
  toggleCategoryModal,
  toggleAIModal,
}) => {
  const { user, logout } = useContext(AuthContext);
  const { categories } = useContext(CategoryContext);
  const [showMore, setShowMore] = useState(false);

  const navigate = useNavigate();
  const location = useLocation();

  const visibleCategories = categories.slice(0, 3);
  const hiddenCategories = categories.slice(3);

  const handleLoginClick = (e) => {
    e.preventDefault();
    toggleLoginModal();
  };

  const handleWriteClick = (e) => {
    e.preventDefault();
    if (!user) {
      toggleLoginModal();
    } else {
      navigate('/write');
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/board/all');
  };

  const handleSearchClick = () => {
    toggleSearchModal();
  };

  const handleCategoryManage = () => {
    toggleCategoryModal();
  };

  return (
    <header className="header">
      {/* 로고 클릭 시 메인으로 */}
      <div className="logo" onClick={() => navigate('/board/all')}>
        MyBoard
      </div>

      {/* 카테고리 네비게이션 */}
      <nav className="nav">
        <Link
          to="/board/all"
          className={`nav-link ${location.pathname === '/board/all' ? 'active' : ''}`}
        >
          <b>전체</b>
        </Link>

        {visibleCategories.map((cat) => (
          <Link
            key={cat.id}
            to={`/board/${encodeURIComponent(cat.name)}`}
            className={`nav-link ${location.pathname === `/board/${encodeURIComponent(cat.name)}` ? 'active' : ''}`}
          >
            {cat.name}
          </Link>
        ))}

        {hiddenCategories.length > 0 && (
          <div className="nav-dropdown">
            <button
              className="nav-link more-btn"
              onClick={() => setShowMore((prev) => !prev)}
            >
              더보기 ▾
            </button>
            {showMore && (
              <div className="dropdown-menu">
                {hiddenCategories.map((cat) => (
                  <Link
                    key={cat.id}
                    to={`/board/${encodeURIComponent(cat.name)}`}
                    className="dropdown-item"
                    onClick={() => setShowMore(false)}
                  >
                    {cat.name}
                  </Link>
                ))}
              </div>
            )}
          </div>
        )}
      </nav>

      {/* 우측 버튼들 */}
      <div className="right">
         {user?.isAdmin && (
    <>
      {/* 관리자 전용 페이지로 이동 */}
      <Link to="/admin" className="btn btn-admin" title="관리자 페이지">
        🔐 관리자
      </Link>

      <button onClick={handleCategoryManage} className="btn btn-manage" title="카테고리 관리">
        ⚙️
      </button>
    </>
  )}
        
        <button onClick={toggleAIModal}>🤖 AI 질문</button>

        <button onClick={handleSearchClick} className="btn btn-search">
          검색
        </button>

        <button onClick={handleWriteClick} className="btn btn-write">
          글쓰기
        </button>

        {user ? (
          <>
            <Link to="/profile" className="user-name">{user.name} 님</Link>
            <button onClick={handleLogout} className="btn btn-logout">로그아웃</button>
          </>
        ) : (
          <button onClick={handleLoginClick} className="btn btn-login">로그인</button>
        )}
      </div>
    </header>
  );
};

export default Header;
