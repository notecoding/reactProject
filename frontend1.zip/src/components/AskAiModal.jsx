// 📁 src/components/AskAIModal.jsx
import React, { useState } from 'react';
import axios from 'axios';
import '../styles/AskAI.css'; // 스타일 포함

const AskAIModal = ({ onClose }) => {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAsk = async () => {
    if (!question.trim()) return;
    setLoading(true);
    setAnswer('');

    try {
      const res = await axios.post('http://localhost:5000/api/ai/ask', { question });
      setAnswer(res.data.answer);
    } catch (err) {
      console.error(err);
      setAnswer('❌ AI 응답에 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <button className="modal-close" onClick={onClose}>✖</button>
        <h2>🤖 AI에게 질문하기</h2>
        <textarea
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="질문을 입력하세요..."
          rows={4}
          className="ask-ai-input"
        />
        <button onClick={handleAsk} disabled={loading} className="ask-ai-button">
          {loading ? '답변 생성 중...' : '질문하기'}
        </button>
        {answer && (
          <div className="ask-ai-answer">
            <h3>📌 AI의 답변:</h3>
            <p>{answer}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AskAIModal;
